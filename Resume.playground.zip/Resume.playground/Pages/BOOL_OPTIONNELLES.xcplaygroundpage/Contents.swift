//: [Previous](@previous)

import Foundation
import UIKit

var str = "Hello, playground"

// Booleen vrai ou faux

var iLoveCodabee : Bool = true
iLoveCodabee = false

var a = 23
var b = 11

var monBooleen: Bool

monBooleen = a == b

monBooleen = a != b

var c = false
var d = true

monBooleen = (c && d) // Si l'une des condition est fausse : Resultat false

monBooleen = (c || d) // Si l'une des condition est vrai : Résultat true



// Optionnels : Variable qui peut contenir ou non une valeur. Swift n'accepte pas de valeur nil sauf pour les optionels

// Déclaration variable Optionnels avec une valeur

var stringOptionelle: String? = "test"

//Déclarer une optionnelle nil (absence de valeur)
stringOptionelle = nil

print(stringOptionelle)

// Le ! aprés la variable force "unwrap" la conversion d'une optionnelle en non optionnelle. Ne jamais l'utiliser sans vérification sinon "crash"
//print(stringOptionelle!)

// Différente maniére de verification à faire avant de convertir une optionnelle en non optionnelle

// 1 : Avec une fonction
func verifier(string: String?)  {
    
    /*
     if string != nil {
     
     print(string!)
     }
     
     */
    
    // 2 : En créant directement une variable
    
    /*
     if let maString = string    {
     
     print(maString)
     }
     */
    
    // 3 : Avec Guard
    
    /*
     guard string != nil else { return }
     print(string!)
     
     */
    
    // Retourner un élément optionnelle : Exemple d'un tableau (On ne sait pas s'il est vide et dans ce cas il ne retourne pas de valeur max
    
    func valeurMax(tab : [Int]) -> Int? {
        
        // 1ére chose tester si le tableau est vide
        
        if tab.isEmpty { return nil }
        
        
        // Retourne la valeur maximum d'un tableau
        
        var max = tab [0]
        for nombre in tab {
            if nombre > max {
                max = nombre
            }
        }
        return max
    }
    
    // test valeur max
    var tableau = [12, 67, 89, -5, 8, 12, 99, 1]
    valeurMax(tab: tableau)
    
    
    // Enlever affichage Optionnal plus la valeur du tableau avec le point d'exclamation
    print("La valeur max du tableau est : \(valeurMax(tab: tableau)!)")
    
    // Toujours tester avant de unwrapp
    
    if let valeurMax = valeurMax(tab: tableau) {
        
        print("La valeur max du tableau est : \(valeurMax)")
    } else  {
        
        print("Le tableau n'a pas de max")
    }
    
    // test nil
    tableau = []
    valeurMax(tab: tableau)
    
    // 4 : Avec guard let
    
    guard let maString = string else { return }
    print(maString)
}

verifier(string: nil) // valeur nil retourne rien
verifier(string: "GO") // Valeur non nil retourne la valeur


// Creer une optionnelle avec valeur
var monOpt: String? = "Paris"

// Créer une optionnelle sans valeur
var monOpt2: Int?

// Convertir une chaîne de caractére en entier
var nombreChaine = "512"
var nombre = Int(nombreChaine)

// Impossibilité de convertir une chaîne de caractére en entier
var nombre2Chaine = "5e1"
var nombre2 = Int(nombre2Chaine)

// Tester une optionelle
if nombre != nil    {
    
    print(nombreChaine)
    
} else {
    
    print("La variable demandée ne contient pas de valeur")
    
}

if let maVariableDeballee = nombre  {
    
    print(maVariableDeballee)
}
